# Monitor de ruido y vibración para lancha (ESP-NOW)

Prototipo 1 · Esquemático en KiCad

**Equipo:** Juan David Martínez Padilla · Samuel Gabriel Medina Arciniegas · Mateo Ruiz Palencia · Juan Sebastián Rojas Rocha · Yised Viviana Bellaizan Valencia

## Descripción

Sistema que evalúa la vibración del casco de una lancha en tiempo real para evitar el enmascaramiento acústico, **sin necesidad de internet ni señal celular**.

- **Nodo 1 (sentina, emisor):** un sensor MAX4466 fijado al casco entrega una señal analógica al ESP32, que calcula la amplitud pico a pico en ventanas de 50 ms. Si el nivel supera un umbral definido, transmite una alerta por radiofrecuencia (ESP-NOW, 2.4 GHz) y guarda en la microSD la lectura, la hora y el estado de alerta (`LOG_RUIDO.CSV`).
- **Nodo 2 (cabina, receptor):** otro ESP32 recibe el paquete, muestra «¡RUIDO CRÍTICO! REDUZCA VELOCIDAD» en una pantalla OLED y activa un LED rojo y un buzzer. La alerta llega en menos de 10 ms.

El resultado es una herramienta de reacción inmediata para el capitán y un banco de datos histórico para los investigadores.

## Esquemático

![Esquemático](docs/esquematico.svg)

PDF: [docs/esquematico.pdf](docs/esquematico.pdf)

## Conexiones

### Nodo 1 · sentina

| Componente | Pin del módulo | Pin del ESP32 |
|---|---|---|
| MAX4466 | VCC | 3V3 |
| MAX4466 | GND | GND |
| MAX4466 | OUT | IO34 |
| Módulo microSD | GND | GND |
| Módulo microSD | VCC | 5V (EXT_5V) |
| Módulo microSD | MISO | IO19 |
| Módulo microSD | MOSI | IO23 |
| Módulo microSD | SCK | IO18 |
| Módulo microSD | CS | IO5 |

### Nodo 2 · cabina

| Componente | Pin del módulo | Pin del ESP32 |
|---|---|---|
| Pantalla OLED | GND | GND |
| Pantalla OLED | VCC | 3V3 |
| Pantalla OLED | SCL | IO22 |
| Pantalla OLED | SDA | IO21 |
| LED rojo (con resistencia de 220 Ω) | ánodo | IO25 |
| LED rojo | cátodo | GND |
| Buzzer | + | IO26 |
| Buzzer | − | GND |

Cada nodo se alimenta con una powerbank de 5 V por el USB del ESP32 y va dentro de una caja IP65.

## Lista de componentes

Precios en pesos colombianos (COP).

| N.º | Componente | Función | Cant. | Precio unitario | Subtotal | Estado del precio |
|---|---|---|---|---|---|---|
| 1 | ESP32-WROOM-32 (DevKit) | Microcontrolador de los nodos 1 y 2 | 2 | $27.437 | $54.874 | Verificado (Didácticas Electrónicas) |
| 2 | Módulo amplificador de micrófono electret MAX4466 | Capta la vibración del casco | 1 | $15.000 | $15.000 | Estimado |
| 3 | Pantalla OLED 0,96" SSD1306 (I2C) | Muestra el mensaje de alerta | 1 | $20.000 | $20.000 | Estimado |
| 4 | Zumbador piezoeléctrico (buzzer) | Alerta sonora | 1 | $2.500 | $2.500 | Estimado |
| 5 | LED rojo de alta intensidad | Alerta luminosa (con resistencia de 220 Ω) | 1 | $300 | $300 | Estimado |
| 6 | Módulo lector de tarjeta microSD (SPI) | Interfaz de almacenamiento | 1 | $7.000 | $7.000 | Estimado |
| 7 | Tarjeta microSD de 16 GB | Almacena LOG_RUIDO.CSV | 1 | $25.000 | $25.000 | Estimado |
| 8 | Powerbank 5 V | Alimentación de cada nodo | 2 | — | — | Por definir |
| 9 | Caja IP65 | Carcasa estanca de cada nodo | 2 | — | — | Por definir |

**Total aproximado (sin los ítems por definir): $124.674**

## Estructura del repositorio

```
monitor-ruido-lancha/
├── monitor-ruido-lancha.kicad_pro   # proyecto de KiCad
├── monitor-ruido-lancha.kicad_sch   # esquemático (ambos nodos)
├── docs/
│   ├── esquematico.pdf
│   └── esquematico.svg
├── .gitignore
└── README.md
```

## Cómo abrir el proyecto

1. Instalar [KiCad](https://www.kicad.org/download/) (versión estable).
2. Clonar o descargar este repositorio.
3. Abrir `monitor-ruido-lancha.kicad_pro`.

## Notas

- Los módulos (ESP32, MAX4466, OLED, microSD) se representan con conectores genéricos cuyos pines siguen el orden del módulo físico.
- En el esquemático ambos nodos comparten hoja; en la realidad cada uno tiene su propia powerbank y su propia tierra.
- El enlace ESP-NOW es inalámbrico, por eso no se dibuja con cable.
- El MAX4466 es un micrófono: capta sonido y vibración transmitida por el casco. Un acelerómetro sería una alternativa a evaluar en próximas versiones.
